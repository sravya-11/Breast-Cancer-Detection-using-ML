# Breast-Cancer-Detection-using-ML
An early diagnosis is found to have remarkable results in saving lives. With this objective in mind, a project has been developed to predict weather the tumor is cancerous or not so that required remdial actions can be taken up to cure it at the earliest.
